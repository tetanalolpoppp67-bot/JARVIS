# JARVIS Android

Package: `com.jarvis.assistant`

This project contains exactly 1500 unique Russian local phrases.

## GitHub Actions
Upload the contents of this archive into a GitHub repository and use a workflow that runs:

`gradle --no-daemon :app:assembleDebug`

The resulting APK is:

`app/build/outputs/apk/debug/app-debug.apk`
