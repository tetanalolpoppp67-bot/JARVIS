package com.jarvis.assistant

import android.app.*
import android.content.Intent
import android.os.IBinder

class JarvisService : Service() {
    private val channel = "jarvis_background"
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channel, "JARVIS", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, channel)
            .setContentTitle("JARVIS активен")
            .setContentText("Фоновый режим голосового помощника")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        startForeground(77, n)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
