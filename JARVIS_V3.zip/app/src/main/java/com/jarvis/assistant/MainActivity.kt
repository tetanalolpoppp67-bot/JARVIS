package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.assistant.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var b: ActivityMainBinding
    private lateinit var tts: TextToSpeech
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        tts = TextToSpeech(this, this)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            permission.launch(Manifest.permission.RECORD_AUDIO)
        b.micButton.setOnClickListener { listenOnce() }
        b.backgroundSwitch.setOnCheckedChangeListener { _, on ->
            if (on) androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
            else stopService(Intent(this, JarvisService::class.java))
            b.status.text = if (on) "Фоновый режим включён" else "Готов к работе"
        }
        b.voiceButton.setOnClickListener { chooseVoice() }
    }

    private fun listenOnce() {
        b.status.text = "Слушаю…"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }
        try { startActivityForResult(i, 101) } catch (_: Exception) { b.status.text = "Распознавание недоступно" }
    }

    override fun onActivityResult(r: Int, result: Int, data: Intent?) {
        super.onActivityResult(r, result, data)
        if (r != 101) return
        b.status.text = "Готов к работе"
        data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { command(it) }
    }

    private fun command(text: String) {
        val s = text.lowercase(Locale("ru"))
        val reply = when {
            "привет" in s -> "Рад вас слышать, сэр."
            "кто ты" in s -> "Я JARVIS, ваш голосовой помощник, сэр."
            "как дела" in s -> "Все системы работают штатно, сэр."
            "который час" in s || "сколько времени" in s ->
                "Сейчас ${SimpleDateFormat("HH:mm", Locale("ru")).format(Date())}, сэр."
            "какая сегодня дата" in s || "какое сегодня число" in s ->
                "Сегодня ${SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date())}, сэр."
            "спасибо" in s -> "Всегда к вашим услугам, сэр."
            "шутку" in s -> "Почему программист любит тёмную тему? Потому что свет привлекает баги, сэр."
            "выключись" in s || "усни" in s -> "Переходя в режим ожидания, сэр."
            else -> "Не совсем понял команду. Повторите, пожалуйста, сэр."
        }
        b.answer.text = reply; speak(reply)
    }

    private fun speak(s: String) { tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }

    private fun chooseVoice() {
        val voices = tts.voices?.filter { it.locale.language == "ru" } ?: emptyList()
        if (voices.isEmpty()) { speak("Русские голоса не найдены. Установите русский голосовой пакет Android."); return }
        val names = voices.map { "${it.name} — ${it.locale.displayName}" }
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Голос JARVIS")
            .setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, names)) { _, n ->
                tts.voice = voices[n]; speak("Голос выбран, сэр.")
            }.show()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("ru", "RU")
            tts.setSpeechRate(0.88f)
            tts.setPitch(0.78f)
        }
    }
    override fun onDestroy() { tts.stop(); tts.shutdown(); super.onDestroy() }
}
