package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var statusText: TextView
    private lateinit var answerText: TextView
    private lateinit var micButton: Button
    private lateinit var reactor: ImageView
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var phrases: List<Phrase> = emptyList()
    private val lastByCategory = mutableMapOf<String, String>()
    private var listening = false

    data class Phrase(val category: String, val text: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusText = findViewById(R.id.statusText)
        answerText = findViewById(R.id.answerText)
        micButton = findViewById(R.id.micButton)
        reactor = findViewById(R.id.reactor)
        phrases = loadPhrases()
        tts = TextToSpeech(this, this)
        micButton.setOnClickListener { if (listening) stopListening() else startListening() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
        answerText.text = randomPhrase("greetings")
    }

    private fun loadPhrases(): List<Phrase> {
        val text = assets.open("phrases.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Phrase(o.getString("category"), o.getString("text"))
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("ru", "RU")
            tts.setSpeechRate(0.94f)
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            speak("Сэр, разрешите доступ к микрофону в настройках Android.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Сэр, на устройстве недоступен системный сервис распознавания речи.")
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening = true
                statusText.text = "Слушаю…"
                micButton.text = "ОСТАНОВИТЬ"
                animateReactor(true)
            }
            override fun onBeginningOfSpeech() { statusText.text = "Слушаю…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "Обрабатываю…" }

            override fun onError(error: Int) {
                listening = false
                micButton.text = "МИКРОФОН"
                animateReactor(false)
                statusText.text = "Готов к работе"
                if (error != SpeechRecognizer.ERROR_CLIENT) speak(randomPhrase("errors"))
            }

            override fun onResults(results: Bundle?) {
                listening = false
                micButton.text = "МИКРОФОН"
                animateReactor(false)
                statusText.text = "Обрабатываю…"
                val heard = results?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )?.firstOrNull().orEmpty()
                handleCommand(heard)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Слушаю вас, сэр…")
        }

        try {
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            speak("Сэр, не удалось запустить распознавание речи.")
        }
    }

    private fun stopListening() {
        recognizer?.stopListening()
        listening = false
        micButton.text = "МИКРОФОН"
        statusText.text = "Готов к работе"
        animateReactor(false)
    }

    private fun handleCommand(raw: String) {
        val cmd = raw.lowercase(Locale("ru", "RU")).trim()
        when {
            cmd.contains("привет") || cmd.contains("здравствуй") -> speak(randomPhrase("greetings"))
            cmd.contains("кто ты") || cmd.contains("ты кто") || cmd.contains("как тебя зовут") -> speak(randomPhrase("identity"))
            cmd.contains("как дела") || cmd.contains("как ты") -> speak(randomPhrase("how_are_you"))
            cmd.contains("который час") || cmd == "сколько времени" || cmd.contains("сколько сейчас времени") -> tellTime()
            cmd.contains("какая сегодня дата") || cmd.contains("какое сегодня число") || cmd.contains("сегодняшняя дата") -> tellDate()
            cmd.contains("скажи шутку") || cmd.contains("расскажи шутку") || cmd.contains("пошути") -> speak(randomPhrase("jokes"))
            cmd == "спасибо" || cmd.contains("спасибо jarvis") || cmd.contains("спасибо, jarvis") -> speak(randomPhrase("thanks"))
            cmd.contains("выключись") || cmd.contains("заверши работу") || cmd.contains("замолчи") -> shutdownAssistant()
            cmd.contains("открой youtube") || cmd.contains("открой ютуб") -> openUrl("https://www.youtube.com", "apps")
            cmd.contains("открой браузер") || cmd.contains("запусти браузер") -> openBrowser()
            cmd.contains("включи музыку") || cmd.contains("открой музыку") -> openMusic()
            cmd.contains("открой настройки") -> openSettings()
            cmd.contains("информация о телефоне") || cmd.contains("сведения о телефоне") -> openDeviceInfo()
            cmd.contains("проверь интернет") || cmd.contains("есть интернет") -> openUrl("https://www.google.com", "internet")
            cmd.contains("игру") || cmd.contains("игры") -> speak(randomPhrase("games"))
            cmd.contains("телефон") && cmd.contains("информа") -> speak(randomPhrase("phone_info"))
            else -> speak(randomPhrase("errors"))
        }
        statusText.text = "Готов к работе"
    }

    private fun tellTime() {
        speak("Сейчас ${SimpleDateFormat("HH:mm", Locale("ru", "RU")).format(Date())}, сэр.")
    }

    private fun tellDate() {
        speak("Сегодня ${SimpleDateFormat("d MMMM yyyy года", Locale("ru", "RU")).format(Date())}, сэр.")
    }

    private fun openUrl(url: String, category: String) {
        speak(randomPhrase(category))
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { speak("Сэр, не удалось открыть ссылку.") }
    }

    private fun openBrowser() = openUrl("https://www.google.com", "apps")

    private fun openMusic() {
        speak(randomPhrase("music"))
        try {
            startActivity(Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_APP_MUSIC) })
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com"))) }
            catch (_: Exception) { speak("Сэр, музыкальное приложение не найдено.") }
        }
    }

    private fun openSettings() {
        speak(randomPhrase("apps"))
        startActivity(Intent(Settings.ACTION_SETTINGS))
    }

    private fun openDeviceInfo() {
        speak(randomPhrase("phone_info"))
        try { startActivity(Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    private fun shutdownAssistant() {
        stopListening()
        speak(randomPhrase("shutdown"))
    }

    private fun randomPhrase(category: String): String {
        val pool = phrases.filter { it.category == category }
        if (pool.isEmpty()) return "Готов к работе, сэр."
        val previous = lastByCategory[category]
        val candidates = pool.filter { it.text != previous }
        val chosen = candidates[Random.nextInt(candidates.size.coerceAtLeast(1))]
        lastByCategory[category] = chosen.text
        return chosen.text
    }

    private fun speak(text: String) {
        answerText.text = text
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
        }
    }

    private fun animateReactor(active: Boolean) {
        if (active) {
            reactor.startAnimation(ScaleAnimation(
                1f, 1.10f, 1f, 1.10f,
                Animation.RELATIVE_TO_SELF, .5f,
                Animation.RELATIVE_TO_SELF, .5f
            ).apply {
                duration = 650
                repeatMode = Animation.REVERSE
                repeatCount = Animation.INFINITE
            })
        } else {
            reactor.clearAnimation()
            reactor.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
